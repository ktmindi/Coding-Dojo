function myBirthYearFunc(){
        console.log("I was born in " + 1980);
    }
 console.log   
 // predict1 will state I was born in 1980
 // predict2 will state I was born in 1980
 // predict 3 will state 30