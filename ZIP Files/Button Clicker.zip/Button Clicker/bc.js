function logout(element){
    element.innerText= "Logout"
}
function disappear(element){
    element.remove();
}