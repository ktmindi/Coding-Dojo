function changeImage(element){
    element.src = "succulents-2.jpg";
}
function changeImageBack(element){
    element.src = "succulents-1.jpg";
}

function myAlert(){
    alert("This site makes use of third-party cookies, by clicking I accept you agree to the terms outlined in our cookie policy.")
}

setTimeout(myAlert,1000)